package beans;

public class Manager {
	private String manID;
	private String manPassword;
	
	public String getManID() {
		return manID;
	}
	public void setManID(String manID) {
		this.manID = manID;
	}
	public String getManPassword() {
		return manPassword;
	}
	public void setManPassword(String manPassword) {
		this.manPassword = manPassword;
	}
}
