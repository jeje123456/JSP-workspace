package controller;

import java.io.IOException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import dao.ManagerOrderDao;
import page.ManagerOrder;

@WebServlet("/managerOrderlist")
public class ManagerOrderController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private ManagerOrderDao managerOrderDao;
	
	@Resource(name = "jdbc/shop")
	private DataSource dataSource;
	
	@Override
	public void init() throws ServletException {
		managerOrderDao = new ManagerOrderDao(dataSource);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 출력 확인
//		List<ManagerOrder> ordersList = managerOrderDao.findAll();
//		ordersList.forEach(ManagerOrder -> System.out.println(ManagerOrder.toString()));

		request.setCharacterEncoding("UTF8");
		// 파라메타 cmd 값을 읽어서 액션으로 저장하는데 만약 값이 null이 아니면 request.getParameter("cmd")가 들어가고 null이면 "list"로 대체
		String action = request.getParameter("cmd") != null ? request.getParameter("cmd") : "list";
		
		switch (action) {
		case "delete":
			delete(request, response);
			break;
		case "edit": // 수정 form을 보여줌
			showEditForm(request, response);
			break;
		case "update":
			update(request, response);
			break;
		case "list":
			ordersList(request, response);
			break;
		case "logout": // 요청 주소가 기본 또는 잘못 되었을 경우 로그인 페이지로 이동
			// 새션에 있는 로그인 정보 없애기
			HttpSession session = request.getSession();
			session.invalidate(); // 새션 전부 삭제
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("login/managerLogin.jsp");
			dispatcher.forward(request, response); 
			break;
		default: // 요청 주소가 기본 또는 잘못 되었을 경우 ordersList로 이동
			ordersList(request, response);
			break;
		} // switch문 끝
	}

	private void showEditForm(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
	}

	private void delete(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
	}

	private void update(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
	}

	private void ordersList(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<ManagerOrder> orders = managerOrderDao.findAll();
		
		request.setAttribute("orders", orders);
		
		RequestDispatcher rd = request.getRequestDispatcher("orders/ordersList.jsp");
		rd.forward(request, response);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
