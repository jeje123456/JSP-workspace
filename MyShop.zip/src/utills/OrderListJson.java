package utills;
//패키지 utills = 뭔가 하는데 도움을 주는 내용 -> Json에서 제이슨으로 만들어서 요청이 오면 OrderListJson에서 응답을 제이슨으로 해줌
import beans.Order;
// 제이슨 형태로 보낼 클래스
public class OrderListJson {
	
	private boolean status;  // 상태 (성공/실패)
	private String message;	 // 메세지 입력
	private Order orderList; // OrderList 객체(1개의 주문)를 하나 입력
	
	public boolean getStatus() {
		return status;
	}
	
	public void setStatus(boolean status) {
		this.status = status;
	}
	
	public String getMessage() {
		return message;
	}
	
	public void setMessage(String message) {
		this.message = message;
	}

	public Order getOrderList() {
		return orderList;
	}

	public void setOrderList(Order orderList) {
		this.orderList = orderList;
	}
	
	

}
